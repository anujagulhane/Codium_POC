export function xframe(type: string): any;
export function xssProtection(enabled: boolean): any;
